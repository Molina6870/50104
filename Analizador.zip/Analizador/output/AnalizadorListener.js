// Generated from Analizador.g4 by ANTLR 4.13.2
// jshint ignore: start
import antlr4 from 'antlr4';

// This class defines a complete listener for a parse tree produced by AnalizadorParser.
export default class AnalizadorListener extends antlr4.tree.ParseTreeListener {

	// Enter a parse tree produced by AnalizadorParser#programa.
	enterPrograma(ctx) {
	}

	// Exit a parse tree produced by AnalizadorParser#programa.
	exitPrograma(ctx) {
	}


	// Enter a parse tree produced by AnalizadorParser#instrucciones.
	enterInstrucciones(ctx) {
	}

	// Exit a parse tree produced by AnalizadorParser#instrucciones.
	exitInstrucciones(ctx) {
	}


	// Enter a parse tree produced by AnalizadorParser#instruccion.
	enterInstruccion(ctx) {
	}

	// Exit a parse tree produced by AnalizadorParser#instruccion.
	exitInstruccion(ctx) {
	}


	// Enter a parse tree produced by AnalizadorParser#bucle.
	enterBucle(ctx) {
	}

	// Exit a parse tree produced by AnalizadorParser#bucle.
	exitBucle(ctx) {
	}


	// Enter a parse tree produced by AnalizadorParser#sentencia.
	enterSentencia(ctx) {
	}

	// Exit a parse tree produced by AnalizadorParser#sentencia.
	exitSentencia(ctx) {
	}


	// Enter a parse tree produced by AnalizadorParser#salida.
	enterSalida(ctx) {
	}

	// Exit a parse tree produced by AnalizadorParser#salida.
	exitSalida(ctx) {
	}


	// Enter a parse tree produced by AnalizadorParser#terminar.
	enterTerminar(ctx) {
	}

	// Exit a parse tree produced by AnalizadorParser#terminar.
	exitTerminar(ctx) {
	}


	// Enter a parse tree produced by AnalizadorParser#condicion.
	enterCondicion(ctx) {
	}

	// Exit a parse tree produced by AnalizadorParser#condicion.
	exitCondicion(ctx) {
	}


	// Enter a parse tree produced by AnalizadorParser#cadena.
	enterCadena(ctx) {
	}

	// Exit a parse tree produced by AnalizadorParser#cadena.
	exitCadena(ctx) {
	}


	// Enter a parse tree produced by AnalizadorParser#caracteres.
	enterCaracteres(ctx) {
	}

	// Exit a parse tree produced by AnalizadorParser#caracteres.
	exitCaracteres(ctx) {
	}


	// Enter a parse tree produced by AnalizadorParser#caracter.
	enterCaracter(ctx) {
	}

	// Exit a parse tree produced by AnalizadorParser#caracter.
	exitCaracter(ctx) {
	}


	// Enter a parse tree produced by AnalizadorParser#letra.
	enterLetra(ctx) {
	}

	// Exit a parse tree produced by AnalizadorParser#letra.
	exitLetra(ctx) {
	}


	// Enter a parse tree produced by AnalizadorParser#digito.
	enterDigito(ctx) {
	}

	// Exit a parse tree produced by AnalizadorParser#digito.
	exitDigito(ctx) {
	}


	// Enter a parse tree produced by AnalizadorParser#simbolo.
	enterSimbolo(ctx) {
	}

	// Exit a parse tree produced by AnalizadorParser#simbolo.
	exitSimbolo(ctx) {
	}



}