const antlr4 = require('antlr4');
const fs = require('fs');

// Leer input desde input.txt
const input = fs.readFileSync('input.txt', 'utf-8');
console.log('=== Input ===\n' + input);

// Cargar los archivos generados por ANTLR
const AnalizadorLexer = require('./output/AnalizadorLexer').default;
const AnalizadorParser = require('./output/AnalizadorParser').default;
const AnalizadorListener = require('./output/AnalizadorListener').default;

// Crear el lexer y el stream de tokens
const chars = new antlr4.InputStream(input);
const lexer = new AnalizadorLexer(chars);
const tokens = new antlr4.CommonTokenStream(lexer);

// Mostrar tabla de tokens
//tokenStream.fill();
console.log('\n📄 Tabla de tokens:\nLexema\t\t|\tToken');
console.log('-----------------------------');

tokens.getTokens().forEach(token => {
    if (token.type !== antlr4.Token.EOF) {
        const symbolicNames = lexer.constructor.symbolicNames || [];
        const literalNames = lexer.constructor.literalNames || [];
        const tokenName =
            symbolicNames[token.type] ??
            literalNames[token.type] ??
            `TOKEN_${token.type}`;

        console.log(`${token.text.padEnd(16)}|\t${tokenName}`);
    }
});


// Crear el parser
const parser = new AnalizadorParser(tokens);

// Manejo de errores
parser.removeErrorListeners();
lexer.removeErrorListeners();
parser.addErrorListener({
    syntaxError: (recognizer, offendingSymbol, line, column, msg) => {
        console.error(`\n❌ Error de sintaxis en línea ${line}, columna ${column}: ${msg}`);
        process.exit(1);
    }
});
lexer.addErrorListener({
    syntaxError: (recognizer, offendingSymbol, line, column, msg) => {
        console.error(`\n❌ Error léxico en línea ${line}, columna ${column}: ${msg}`);
        process.exit(1);
    }
});

// Realizar el análisis sintáctico
const tree = parser.programa();

// Mostrar árbol de derivación
console.log('\n🌳 Árbol de Derivación:\n' + tree.toStringTree(parser.ruleNames));

// Intérprete básico
class MiListener extends AnalizadorListener {
    constructor() {
        super();
        this.ejecutar = true;
    }

    enterSalida(ctx) {
        if (this.ejecutar) {
            const letras = ctx.cadena().getText();
            console.log(`\n🖨️ salida: ${letras}`);
        }
    }

    enterTerminar(ctx) {
        this.ejecutar = false;
        console.log('\n🚫 break encontrado. Se detiene la ejecución.');
    }
}

// Ejecutar el listener
antlr4.tree.ParseTreeWalker.DEFAULT.walk(new MiListener(), tree);

