// Generated from c:/Users/juani/OneDrive/Escritorio/Juani/generated/Analizador.g4 by ANTLR 4.13.2
// jshint ignore: start
import antlr4 from 'antlr4';


const serializedATN = [4,0,16,91,6,-1,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,
4,7,4,2,5,7,5,2,6,7,6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,
12,2,13,7,13,2,14,7,14,2,15,7,15,1,0,1,0,1,1,1,1,1,2,1,2,1,3,1,3,1,3,1,3,
1,3,1,4,1,4,1,4,1,4,1,4,1,4,1,5,1,5,1,5,1,6,1,6,1,6,1,6,1,6,1,6,1,7,1,7,
1,7,1,7,5,7,64,8,7,10,7,12,7,67,9,7,1,7,1,7,1,8,1,8,1,9,1,9,1,10,1,10,1,
11,1,11,1,12,1,12,1,13,1,13,1,14,1,14,1,15,4,15,86,8,15,11,15,12,15,87,1,
15,1,15,0,0,16,1,1,3,2,5,3,7,4,9,5,11,6,13,7,15,8,17,9,19,10,21,11,23,12,
25,13,27,14,29,15,31,16,1,0,4,2,0,65,90,97,122,1,0,48,57,6,0,33,34,39,39,
44,44,46,46,58,59,63,63,3,0,9,10,13,13,32,32,94,0,1,1,0,0,0,0,3,1,0,0,0,
0,5,1,0,0,0,0,7,1,0,0,0,0,9,1,0,0,0,0,11,1,0,0,0,0,13,1,0,0,0,0,15,1,0,0,
0,0,17,1,0,0,0,0,19,1,0,0,0,0,21,1,0,0,0,0,23,1,0,0,0,0,25,1,0,0,0,0,27,
1,0,0,0,0,29,1,0,0,0,0,31,1,0,0,0,1,33,1,0,0,0,3,35,1,0,0,0,5,37,1,0,0,0,
7,39,1,0,0,0,9,44,1,0,0,0,11,50,1,0,0,0,13,53,1,0,0,0,15,59,1,0,0,0,17,70,
1,0,0,0,19,72,1,0,0,0,21,74,1,0,0,0,23,76,1,0,0,0,25,78,1,0,0,0,27,80,1,
0,0,0,29,82,1,0,0,0,31,85,1,0,0,0,33,34,7,0,0,0,34,2,1,0,0,0,35,36,7,1,0,
0,36,4,1,0,0,0,37,38,7,2,0,0,38,6,1,0,0,0,39,40,5,112,0,0,40,41,5,117,0,
0,41,42,5,116,0,0,42,43,5,115,0,0,43,8,1,0,0,0,44,45,5,98,0,0,45,46,5,114,
0,0,46,47,5,101,0,0,47,48,5,97,0,0,48,49,5,107,0,0,49,10,1,0,0,0,50,51,5,
100,0,0,51,52,5,111,0,0,52,12,1,0,0,0,53,54,5,119,0,0,54,55,5,104,0,0,55,
56,5,105,0,0,56,57,5,108,0,0,57,58,5,101,0,0,58,14,1,0,0,0,59,65,5,34,0,
0,60,64,3,1,0,0,61,64,3,3,1,0,62,64,3,5,2,0,63,60,1,0,0,0,63,61,1,0,0,0,
63,62,1,0,0,0,64,67,1,0,0,0,65,63,1,0,0,0,65,66,1,0,0,0,66,68,1,0,0,0,67,
65,1,0,0,0,68,69,5,34,0,0,69,16,1,0,0,0,70,71,5,40,0,0,71,18,1,0,0,0,72,
73,5,41,0,0,73,20,1,0,0,0,74,75,5,123,0,0,75,22,1,0,0,0,76,77,5,125,0,0,
77,24,1,0,0,0,78,79,5,59,0,0,79,26,1,0,0,0,80,81,5,48,0,0,81,28,1,0,0,0,
82,83,5,49,0,0,83,30,1,0,0,0,84,86,7,3,0,0,85,84,1,0,0,0,86,87,1,0,0,0,87,
85,1,0,0,0,87,88,1,0,0,0,88,89,1,0,0,0,89,90,6,15,0,0,90,32,1,0,0,0,4,0,
63,65,87,1,6,0,0];


const atn = new antlr4.atn.ATNDeserializer().deserialize(serializedATN);

const decisionsToDFA = atn.decisionToState.map( (ds, index) => new antlr4.dfa.DFA(ds, index) );

export default class AnalizadorLexer extends antlr4.Lexer {

    static grammarFileName = "Analizador.g4";
    static channelNames = [ "DEFAULT_TOKEN_CHANNEL", "HIDDEN" ];
	static modeNames = [ "DEFAULT_MODE" ];
	static literalNames = [ null, null, null, null, "'puts'", "'break'", "'do'", 
                         "'while'", null, "'('", "')'", "'{'", "'}'", "';'", 
                         "'0'", "'1'" ];
	static symbolicNames = [ null, "LETRA", "DIGITO", "SIMBOLO", "PUTS", "BREAK", 
                          "DO", "WHILE", "STRING", "LPAREN", "RPAREN", "LBRACE", 
                          "RBRACE", "SEMI", "CERO", "UNO", "WS" ];
	static ruleNames = [ "LETRA", "DIGITO", "SIMBOLO", "PUTS", "BREAK", "DO", 
                      "WHILE", "STRING", "LPAREN", "RPAREN", "LBRACE", "RBRACE", 
                      "SEMI", "CERO", "UNO", "WS" ];

    constructor(input) {
        super(input)
        this._interp = new antlr4.atn.LexerATNSimulator(this, atn, decisionsToDFA, new antlr4.atn.PredictionContextCache());
    }
}

AnalizadorLexer.EOF = antlr4.Token.EOF;
AnalizadorLexer.LETRA = 1;
AnalizadorLexer.DIGITO = 2;
AnalizadorLexer.SIMBOLO = 3;
AnalizadorLexer.PUTS = 4;
AnalizadorLexer.BREAK = 5;
AnalizadorLexer.DO = 6;
AnalizadorLexer.WHILE = 7;
AnalizadorLexer.STRING = 8;
AnalizadorLexer.LPAREN = 9;
AnalizadorLexer.RPAREN = 10;
AnalizadorLexer.LBRACE = 11;
AnalizadorLexer.RBRACE = 12;
AnalizadorLexer.SEMI = 13;
AnalizadorLexer.CERO = 14;
AnalizadorLexer.UNO = 15;
AnalizadorLexer.WS = 16;



